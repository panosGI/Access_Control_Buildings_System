package com.aueb.team04.ft.representation;

public class AccessRequestRepresentation {
    public EmployeeRepresentation employee;
    public Long buildingID;
    public String requestedAccessLevel;
}