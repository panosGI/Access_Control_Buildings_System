package com.aueb.team04.ft.representation;

public class EmployeeRepresentation {
    public Long id;
    public String username;
    public String password;
    public String email;
}
