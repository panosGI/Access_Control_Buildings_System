package com.aueb.team04.ft.resource;

import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.ApplicationPath;

@ApplicationPath("/")
public class RestApplication extends Application {

}