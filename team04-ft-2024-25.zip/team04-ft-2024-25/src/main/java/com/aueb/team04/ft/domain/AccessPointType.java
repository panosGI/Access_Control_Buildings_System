package com.aueb.team04.ft.domain;

public enum AccessPointType {
    INPUT, 
    OUTPUT,
    IN_BETWEEN
}